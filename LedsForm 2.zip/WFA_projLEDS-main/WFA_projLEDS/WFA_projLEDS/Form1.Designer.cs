﻿namespace WFA_projLEDS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picLed1 = new System.Windows.Forms.PictureBox();
            this.picLed2 = new System.Windows.Forms.PictureBox();
            this.picLed3 = new System.Windows.Forms.PictureBox();
            this.picLed4 = new System.Windows.Forms.PictureBox();
            this.picLed5 = new System.Windows.Forms.PictureBox();
            this.picLed6 = new System.Windows.Forms.PictureBox();
            this.picLed7 = new System.Windows.Forms.PictureBox();
            this.picLed8 = new System.Windows.Forms.PictureBox();
            this.btnON1 = new System.Windows.Forms.Button();
            this.btnOFF1 = new System.Windows.Forms.Button();
            this.btnOFF2 = new System.Windows.Forms.Button();
            this.btnON2 = new System.Windows.Forms.Button();
            this.btnOFF3 = new System.Windows.Forms.Button();
            this.btnON3 = new System.Windows.Forms.Button();
            this.btnOFF4 = new System.Windows.Forms.Button();
            this.btnON4 = new System.Windows.Forms.Button();
            this.btnOFF5 = new System.Windows.Forms.Button();
            this.btnON5 = new System.Windows.Forms.Button();
            this.btnOFF6 = new System.Windows.Forms.Button();
            this.btnON6 = new System.Windows.Forms.Button();
            this.btnOFF7 = new System.Windows.Forms.Button();
            this.btnON7 = new System.Windows.Forms.Button();
            this.btnOFF8 = new System.Windows.Forms.Button();
            this.btnON8 = new System.Windows.Forms.Button();
            this.lblEstado = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picLed1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed8)).BeginInit();
            this.SuspendLayout();
            // 
            // picLed1
            // 
            this.picLed1.Image = global::WFA_projLEDS.Properties.Resources.LampadaApagada;
            this.picLed1.Location = new System.Drawing.Point(1001, 98);
            this.picLed1.Name = "picLed1";
            this.picLed1.Size = new System.Drawing.Size(136, 192);
            this.picLed1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLed1.TabIndex = 0;
            this.picLed1.TabStop = false;
            // 
            // picLed2
            // 
            this.picLed2.Image = global::WFA_projLEDS.Properties.Resources.LampadaApagada;
            this.picLed2.Location = new System.Drawing.Point(859, 98);
            this.picLed2.Name = "picLed2";
            this.picLed2.Size = new System.Drawing.Size(136, 192);
            this.picLed2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLed2.TabIndex = 1;
            this.picLed2.TabStop = false;
            // 
            // picLed3
            // 
            this.picLed3.Image = global::WFA_projLEDS.Properties.Resources.LampadaApagada;
            this.picLed3.Location = new System.Drawing.Point(717, 98);
            this.picLed3.Name = "picLed3";
            this.picLed3.Size = new System.Drawing.Size(136, 192);
            this.picLed3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLed3.TabIndex = 2;
            this.picLed3.TabStop = false;
            // 
            // picLed4
            // 
            this.picLed4.Image = global::WFA_projLEDS.Properties.Resources.LampadaApagada;
            this.picLed4.Location = new System.Drawing.Point(575, 98);
            this.picLed4.Name = "picLed4";
            this.picLed4.Size = new System.Drawing.Size(136, 192);
            this.picLed4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLed4.TabIndex = 3;
            this.picLed4.TabStop = false;
            // 
            // picLed5
            // 
            this.picLed5.Image = global::WFA_projLEDS.Properties.Resources.LampadaApagada;
            this.picLed5.Location = new System.Drawing.Point(433, 98);
            this.picLed5.Name = "picLed5";
            this.picLed5.Size = new System.Drawing.Size(136, 192);
            this.picLed5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLed5.TabIndex = 4;
            this.picLed5.TabStop = false;
            // 
            // picLed6
            // 
            this.picLed6.Image = global::WFA_projLEDS.Properties.Resources.LampadaApagada;
            this.picLed6.Location = new System.Drawing.Point(291, 98);
            this.picLed6.Name = "picLed6";
            this.picLed6.Size = new System.Drawing.Size(136, 192);
            this.picLed6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLed6.TabIndex = 5;
            this.picLed6.TabStop = false;
            // 
            // picLed7
            // 
            this.picLed7.Image = global::WFA_projLEDS.Properties.Resources.LampadaApagada;
            this.picLed7.Location = new System.Drawing.Point(149, 98);
            this.picLed7.Name = "picLed7";
            this.picLed7.Size = new System.Drawing.Size(136, 192);
            this.picLed7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLed7.TabIndex = 6;
            this.picLed7.TabStop = false;
            // 
            // picLed8
            // 
            this.picLed8.Image = global::WFA_projLEDS.Properties.Resources.LampadaApagada;
            this.picLed8.Location = new System.Drawing.Point(7, 98);
            this.picLed8.Name = "picLed8";
            this.picLed8.Size = new System.Drawing.Size(136, 192);
            this.picLed8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLed8.TabIndex = 7;
            this.picLed8.TabStop = false;
            // 
            // btnON1
            // 
            this.btnON1.Location = new System.Drawing.Point(1029, 296);
            this.btnON1.Name = "btnON1";
            this.btnON1.Size = new System.Drawing.Size(80, 39);
            this.btnON1.TabIndex = 8;
            this.btnON1.Text = "ON";
            this.btnON1.UseVisualStyleBackColor = true;
            this.btnON1.Click += new System.EventHandler(this.btnON1_Click);
            // 
            // btnOFF1
            // 
            this.btnOFF1.Location = new System.Drawing.Point(1029, 341);
            this.btnOFF1.Name = "btnOFF1";
            this.btnOFF1.Size = new System.Drawing.Size(80, 39);
            this.btnOFF1.TabIndex = 9;
            this.btnOFF1.Text = "OFF";
            this.btnOFF1.UseVisualStyleBackColor = true;
            this.btnOFF1.Click += new System.EventHandler(this.btnOFF1_Click);
            // 
            // btnOFF2
            // 
            this.btnOFF2.Location = new System.Drawing.Point(895, 341);
            this.btnOFF2.Name = "btnOFF2";
            this.btnOFF2.Size = new System.Drawing.Size(80, 39);
            this.btnOFF2.TabIndex = 11;
            this.btnOFF2.Text = "OFF";
            this.btnOFF2.UseVisualStyleBackColor = true;
            this.btnOFF2.Click += new System.EventHandler(this.btnOFF2_Click);
            // 
            // btnON2
            // 
            this.btnON2.Location = new System.Drawing.Point(895, 296);
            this.btnON2.Name = "btnON2";
            this.btnON2.Size = new System.Drawing.Size(80, 39);
            this.btnON2.TabIndex = 10;
            this.btnON2.Text = "ON";
            this.btnON2.UseVisualStyleBackColor = true;
            this.btnON2.Click += new System.EventHandler(this.btnON2_Click);
            // 
            // btnOFF3
            // 
            this.btnOFF3.Location = new System.Drawing.Point(746, 341);
            this.btnOFF3.Name = "btnOFF3";
            this.btnOFF3.Size = new System.Drawing.Size(80, 39);
            this.btnOFF3.TabIndex = 13;
            this.btnOFF3.Text = "OFF";
            this.btnOFF3.UseVisualStyleBackColor = true;
            this.btnOFF3.Click += new System.EventHandler(this.btnOFF3_Click);
            // 
            // btnON3
            // 
            this.btnON3.Location = new System.Drawing.Point(746, 296);
            this.btnON3.Name = "btnON3";
            this.btnON3.Size = new System.Drawing.Size(80, 39);
            this.btnON3.TabIndex = 12;
            this.btnON3.Text = "ON";
            this.btnON3.UseVisualStyleBackColor = true;
            this.btnON3.Click += new System.EventHandler(this.btnON3_Click);
            // 
            // btnOFF4
            // 
            this.btnOFF4.Location = new System.Drawing.Point(607, 341);
            this.btnOFF4.Name = "btnOFF4";
            this.btnOFF4.Size = new System.Drawing.Size(80, 39);
            this.btnOFF4.TabIndex = 15;
            this.btnOFF4.Text = "OFF";
            this.btnOFF4.UseVisualStyleBackColor = true;
            this.btnOFF4.Click += new System.EventHandler(this.btnOFF4_Click);
            // 
            // btnON4
            // 
            this.btnON4.Location = new System.Drawing.Point(607, 296);
            this.btnON4.Name = "btnON4";
            this.btnON4.Size = new System.Drawing.Size(80, 39);
            this.btnON4.TabIndex = 14;
            this.btnON4.Text = "ON";
            this.btnON4.UseVisualStyleBackColor = true;
            this.btnON4.Click += new System.EventHandler(this.btnON4_Click);
            // 
            // btnOFF5
            // 
            this.btnOFF5.Location = new System.Drawing.Point(461, 341);
            this.btnOFF5.Name = "btnOFF5";
            this.btnOFF5.Size = new System.Drawing.Size(80, 39);
            this.btnOFF5.TabIndex = 17;
            this.btnOFF5.Text = "OFF";
            this.btnOFF5.UseVisualStyleBackColor = true;
            this.btnOFF5.Click += new System.EventHandler(this.btnOFF5_Click);
            // 
            // btnON5
            // 
            this.btnON5.Location = new System.Drawing.Point(461, 296);
            this.btnON5.Name = "btnON5";
            this.btnON5.Size = new System.Drawing.Size(80, 39);
            this.btnON5.TabIndex = 16;
            this.btnON5.Text = "ON";
            this.btnON5.UseVisualStyleBackColor = true;
            this.btnON5.Click += new System.EventHandler(this.btnON5_Click);
            // 
            // btnOFF6
            // 
            this.btnOFF6.Location = new System.Drawing.Point(318, 341);
            this.btnOFF6.Name = "btnOFF6";
            this.btnOFF6.Size = new System.Drawing.Size(80, 39);
            this.btnOFF6.TabIndex = 19;
            this.btnOFF6.Text = "OFF";
            this.btnOFF6.UseVisualStyleBackColor = true;
            this.btnOFF6.Click += new System.EventHandler(this.btnOFF6_Click);
            // 
            // btnON6
            // 
            this.btnON6.Location = new System.Drawing.Point(318, 296);
            this.btnON6.Name = "btnON6";
            this.btnON6.Size = new System.Drawing.Size(80, 39);
            this.btnON6.TabIndex = 18;
            this.btnON6.Text = "ON";
            this.btnON6.UseVisualStyleBackColor = true;
            this.btnON6.Click += new System.EventHandler(this.btnON6_Click);
            // 
            // btnOFF7
            // 
            this.btnOFF7.Location = new System.Drawing.Point(178, 341);
            this.btnOFF7.Name = "btnOFF7";
            this.btnOFF7.Size = new System.Drawing.Size(80, 39);
            this.btnOFF7.TabIndex = 21;
            this.btnOFF7.Text = "OFF";
            this.btnOFF7.UseVisualStyleBackColor = true;
            this.btnOFF7.Click += new System.EventHandler(this.btnOFF7_Click);
            // 
            // btnON7
            // 
            this.btnON7.Location = new System.Drawing.Point(178, 296);
            this.btnON7.Name = "btnON7";
            this.btnON7.Size = new System.Drawing.Size(80, 39);
            this.btnON7.TabIndex = 20;
            this.btnON7.Text = "ON";
            this.btnON7.UseVisualStyleBackColor = true;
            this.btnON7.Click += new System.EventHandler(this.btnON7_Click);
            // 
            // btnOFF8
            // 
            this.btnOFF8.Location = new System.Drawing.Point(34, 341);
            this.btnOFF8.Name = "btnOFF8";
            this.btnOFF8.Size = new System.Drawing.Size(80, 39);
            this.btnOFF8.TabIndex = 23;
            this.btnOFF8.Text = "OFF";
            this.btnOFF8.UseVisualStyleBackColor = true;
            this.btnOFF8.Click += new System.EventHandler(this.btnOFF8_Click);
            // 
            // btnON8
            // 
            this.btnON8.Location = new System.Drawing.Point(34, 296);
            this.btnON8.Name = "btnON8";
            this.btnON8.Size = new System.Drawing.Size(80, 39);
            this.btnON8.TabIndex = 22;
            this.btnON8.Text = "ON";
            this.btnON8.UseVisualStyleBackColor = true;
            this.btnON8.Click += new System.EventHandler(this.btnON8_Click);
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstado.Location = new System.Drawing.Point(544, 30);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(109, 39);
            this.lblEstado.TabIndex = 24;
            this.lblEstado.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1149, 472);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.btnOFF8);
            this.Controls.Add(this.btnON8);
            this.Controls.Add(this.btnOFF7);
            this.Controls.Add(this.btnON7);
            this.Controls.Add(this.btnOFF6);
            this.Controls.Add(this.btnON6);
            this.Controls.Add(this.btnOFF5);
            this.Controls.Add(this.btnON5);
            this.Controls.Add(this.btnOFF4);
            this.Controls.Add(this.btnON4);
            this.Controls.Add(this.btnOFF3);
            this.Controls.Add(this.btnON3);
            this.Controls.Add(this.btnOFF2);
            this.Controls.Add(this.btnON2);
            this.Controls.Add(this.btnOFF1);
            this.Controls.Add(this.btnON1);
            this.Controls.Add(this.picLed8);
            this.Controls.Add(this.picLed7);
            this.Controls.Add(this.picLed6);
            this.Controls.Add(this.picLed5);
            this.Controls.Add(this.picLed4);
            this.Controls.Add(this.picLed3);
            this.Controls.Add(this.picLed2);
            this.Controls.Add(this.picLed1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picLed1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLed8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picLed1;
        private System.Windows.Forms.PictureBox picLed2;
        private System.Windows.Forms.PictureBox picLed3;
        private System.Windows.Forms.PictureBox picLed4;
        private System.Windows.Forms.PictureBox picLed5;
        private System.Windows.Forms.PictureBox picLed6;
        private System.Windows.Forms.PictureBox picLed7;
        private System.Windows.Forms.PictureBox picLed8;
        private System.Windows.Forms.Button btnON1;
        private System.Windows.Forms.Button btnOFF1;
        private System.Windows.Forms.Button btnOFF2;
        private System.Windows.Forms.Button btnON2;
        private System.Windows.Forms.Button btnOFF3;
        private System.Windows.Forms.Button btnON3;
        private System.Windows.Forms.Button btnOFF4;
        private System.Windows.Forms.Button btnON4;
        private System.Windows.Forms.Button btnOFF5;
        private System.Windows.Forms.Button btnON5;
        private System.Windows.Forms.Button btnOFF6;
        private System.Windows.Forms.Button btnON6;
        private System.Windows.Forms.Button btnOFF7;
        private System.Windows.Forms.Button btnON7;
        private System.Windows.Forms.Button btnOFF8;
        private System.Windows.Forms.Button btnON8;
        private System.Windows.Forms.Label lblEstado;
    }
}

